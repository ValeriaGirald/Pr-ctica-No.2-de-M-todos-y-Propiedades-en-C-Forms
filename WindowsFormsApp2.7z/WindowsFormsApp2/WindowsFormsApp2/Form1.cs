﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            IniciarFormulario();
        }

        private void IniciarFormulario()
        {
            try
            {
                cmbOrigen.Text = "";
                cmbDestino.Text = "";

                #region [Combo Moneda de Origen]
                cmbOrigen.Items.Clear();
                cmbOrigen.Items.Add("BOGOTA");
                cmbOrigen.Items.Add("MEDELLIN");
                cmbOrigen.Items.Add("CALI");
                #endregion

                #region [Combo Moneda de Destino]
                cmbDestino.Items.Clear();
                cmbDestino.Items.Add("DUBAI");
                cmbDestino.Items.Add("BUENOSAIRES");
                cmbDestino.Items.Add("AUSTRALIA");
                #endregion

            }

            catch (Exception Err)
            {

                MessageBox.Show(Err.Message);
            }

        }

    }

}
