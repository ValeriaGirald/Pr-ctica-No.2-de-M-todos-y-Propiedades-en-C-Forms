﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
   public class clsvuelo
    {
    public  string Origen { get; set; }
    public string Destino{ get; set; }
    public  DateTime FechaSalida { get; set; }
    public int AsientosDisponibles { get; set; }


        public clsvuelo(string origen, string destino, DateTime fechasalida, int asientosdisponibles)
        {
            Origen = origen;
            Destino = destino;
            FechaSalida = fechasalida;
            AsientosDisponibles = asientosdisponibles;
          
        }

        public bool ReservarAsientos(int cantidad)
        {
            if (cantidad <= AsientosDisponibles)
            {
                AsientosDisponibles -= cantidad;
                return true;
            }
            return false;
        }
    }

}
