﻿
namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReservar = new System.Windows.Forms.Button();
            this.cmbOrigen = new System.Windows.Forms.ComboBox();
            this.cmbDestino = new System.Windows.Forms.ComboBox();
            this.lblOrigen = new System.Windows.Forms.Label();
            this.lblDestino = new System.Windows.Forms.Label();
            this.lblNumeroDeAsientos = new System.Windows.Forms.Label();
            this.txtNumeroasientosdisp = new System.Windows.Forms.TextBox();
            this.txtFechasalida = new System.Windows.Forms.TextBox();
            this.lblFechasalida = new System.Windows.Forms.Label();
            this.txtAsientosreserva = new System.Windows.Forms.TextBox();
            this.lblAsientosReserva = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnReservar
            // 
            this.btnReservar.Location = new System.Drawing.Point(327, 272);
            this.btnReservar.Name = "btnReservar";
            this.btnReservar.Size = new System.Drawing.Size(140, 43);
            this.btnReservar.TabIndex = 0;
            this.btnReservar.Text = "RESERVAR";
            this.btnReservar.UseVisualStyleBackColor = true;
            // 
            // cmbOrigen
            // 
            this.cmbOrigen.FormattingEnabled = true;
            this.cmbOrigen.Location = new System.Drawing.Point(72, 54);
            this.cmbOrigen.Name = "cmbOrigen";
            this.cmbOrigen.Size = new System.Drawing.Size(184, 21);
            this.cmbOrigen.TabIndex = 1;
            // 
            // cmbDestino
            // 
            this.cmbDestino.FormattingEnabled = true;
            this.cmbDestino.Location = new System.Drawing.Point(283, 54);
            this.cmbDestino.Name = "cmbDestino";
            this.cmbDestino.Size = new System.Drawing.Size(184, 21);
            this.cmbDestino.TabIndex = 2;
            // 
            // lblOrigen
            // 
            this.lblOrigen.AutoSize = true;
            this.lblOrigen.Location = new System.Drawing.Point(69, 38);
            this.lblOrigen.Name = "lblOrigen";
            this.lblOrigen.Size = new System.Drawing.Size(38, 13);
            this.lblOrigen.TabIndex = 3;
            this.lblOrigen.Text = "Origen";
            // 
            // lblDestino
            // 
            this.lblDestino.AutoSize = true;
            this.lblDestino.Location = new System.Drawing.Point(280, 38);
            this.lblDestino.Name = "lblDestino";
            this.lblDestino.Size = new System.Drawing.Size(43, 13);
            this.lblDestino.TabIndex = 4;
            this.lblDestino.Text = "Destino";
            // 
            // lblNumeroDeAsientos
            // 
            this.lblNumeroDeAsientos.AutoSize = true;
            this.lblNumeroDeAsientos.Location = new System.Drawing.Point(69, 131);
            this.lblNumeroDeAsientos.Name = "lblNumeroDeAsientos";
            this.lblNumeroDeAsientos.Size = new System.Drawing.Size(156, 13);
            this.lblNumeroDeAsientos.TabIndex = 5;
            this.lblNumeroDeAsientos.Text = "Numero de asientos disponibles";
            // 
            // txtNumeroasientosdisp
            // 
            this.txtNumeroasientosdisp.Location = new System.Drawing.Point(72, 147);
            this.txtNumeroasientosdisp.Name = "txtNumeroasientosdisp";
            this.txtNumeroasientosdisp.Size = new System.Drawing.Size(153, 20);
            this.txtNumeroasientosdisp.TabIndex = 6;
            // 
            // txtFechasalida
            // 
            this.txtFechasalida.Location = new System.Drawing.Point(283, 147);
            this.txtFechasalida.Name = "txtFechasalida";
            this.txtFechasalida.Size = new System.Drawing.Size(153, 20);
            this.txtFechasalida.TabIndex = 7;
            // 
            // lblFechasalida
            // 
            this.lblFechasalida.AutoSize = true;
            this.lblFechasalida.Location = new System.Drawing.Point(280, 131);
            this.lblFechasalida.Name = "lblFechasalida";
            this.lblFechasalida.Size = new System.Drawing.Size(67, 13);
            this.lblFechasalida.TabIndex = 8;
            this.lblFechasalida.Text = "Fecha salida";
            // 
            // txtAsientosreserva
            // 
            this.txtAsientosreserva.Location = new System.Drawing.Point(72, 227);
            this.txtAsientosreserva.Name = "txtAsientosreserva";
            this.txtAsientosreserva.Size = new System.Drawing.Size(153, 20);
            this.txtAsientosreserva.TabIndex = 9;
            // 
            // lblAsientosReserva
            // 
            this.lblAsientosReserva.AutoSize = true;
            this.lblAsientosReserva.Location = new System.Drawing.Point(69, 211);
            this.lblAsientosReserva.Name = "lblAsientosReserva";
            this.lblAsientosReserva.Size = new System.Drawing.Size(141, 13);
            this.lblAsientosReserva.TabIndex = 10;
            this.lblAsientosReserva.Text = "Asientos que desea reservar";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAsientosReserva);
            this.Controls.Add(this.txtAsientosreserva);
            this.Controls.Add(this.lblFechasalida);
            this.Controls.Add(this.txtFechasalida);
            this.Controls.Add(this.txtNumeroasientosdisp);
            this.Controls.Add(this.lblNumeroDeAsientos);
            this.Controls.Add(this.lblDestino);
            this.Controls.Add(this.lblOrigen);
            this.Controls.Add(this.cmbDestino);
            this.Controls.Add(this.cmbOrigen);
            this.Controls.Add(this.btnReservar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReservar;
        private System.Windows.Forms.ComboBox cmbOrigen;
        private System.Windows.Forms.ComboBox cmbDestino;
        private System.Windows.Forms.Label lblOrigen;
        private System.Windows.Forms.Label lblDestino;
        private System.Windows.Forms.Label lblNumeroDeAsientos;
        private System.Windows.Forms.TextBox txtNumeroasientosdisp;
        private System.Windows.Forms.TextBox txtFechasalida;
        private System.Windows.Forms.Label lblFechasalida;
        private System.Windows.Forms.TextBox txtAsientosreserva;
        private System.Windows.Forms.Label lblAsientosReserva;
    }
}

