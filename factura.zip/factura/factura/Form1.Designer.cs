﻿namespace factura
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNombreCliente = new System.Windows.Forms.Label();
            this.lblCantidadItem = new System.Windows.Forms.Label();
            this.lblPrecioItem = new System.Windows.Forms.Label();
            this.lblNombreItem = new System.Windows.Forms.Label();
            this.txtNombreCliente = new System.Windows.Forms.TextBox();
            this.txtCantidadItem = new System.Windows.Forms.TextBox();
            this.txtPrecioItem = new System.Windows.Forms.TextBox();
            this.txtNombreItem = new System.Windows.Forms.TextBox();
            this.btnCalcularTotal = new System.Windows.Forms.Button();
            this.btnAgregarItem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNombreCliente
            // 
            this.lblNombreCliente.AutoSize = true;
            this.lblNombreCliente.Location = new System.Drawing.Point(124, 86);
            this.lblNombreCliente.Name = "lblNombreCliente";
            this.lblNombreCliente.Size = new System.Drawing.Size(105, 17);
            this.lblNombreCliente.TabIndex = 0;
            this.lblNombreCliente.Text = "Nombre Cliente";
            // 
            // lblCantidadItem
            // 
            this.lblCantidadItem.AutoSize = true;
            this.lblCantidadItem.Location = new System.Drawing.Point(124, 206);
            this.lblCantidadItem.Name = "lblCantidadItem";
            this.lblCantidadItem.Size = new System.Drawing.Size(94, 17);
            this.lblCantidadItem.TabIndex = 3;
            this.lblCantidadItem.Text = "Cantidad Item";
            // 
            // lblPrecioItem
            // 
            this.lblPrecioItem.AutoSize = true;
            this.lblPrecioItem.Location = new System.Drawing.Point(124, 166);
            this.lblPrecioItem.Name = "lblPrecioItem";
            this.lblPrecioItem.Size = new System.Drawing.Size(78, 17);
            this.lblPrecioItem.TabIndex = 4;
            this.lblPrecioItem.Text = "Precio Item";
            // 
            // lblNombreItem
            // 
            this.lblNombreItem.AutoSize = true;
            this.lblNombreItem.Location = new System.Drawing.Point(124, 126);
            this.lblNombreItem.Name = "lblNombreItem";
            this.lblNombreItem.Size = new System.Drawing.Size(88, 17);
            this.lblNombreItem.TabIndex = 5;
            this.lblNombreItem.Text = "Nombre item";
            // 
            // txtNombreCliente
            // 
            this.txtNombreCliente.Location = new System.Drawing.Point(287, 83);
            this.txtNombreCliente.Name = "txtNombreCliente";
            this.txtNombreCliente.Size = new System.Drawing.Size(100, 22);
            this.txtNombreCliente.TabIndex = 6;
            // 
            // txtCantidadItem
            // 
            this.txtCantidadItem.Location = new System.Drawing.Point(287, 206);
            this.txtCantidadItem.Name = "txtCantidadItem";
            this.txtCantidadItem.Size = new System.Drawing.Size(100, 22);
            this.txtCantidadItem.TabIndex = 7;
            // 
            // txtPrecioItem
            // 
            this.txtPrecioItem.Location = new System.Drawing.Point(287, 163);
            this.txtPrecioItem.Name = "txtPrecioItem";
            this.txtPrecioItem.Size = new System.Drawing.Size(100, 22);
            this.txtPrecioItem.TabIndex = 8;
            // 
            // txtNombreItem
            // 
            this.txtNombreItem.Location = new System.Drawing.Point(287, 121);
            this.txtNombreItem.Name = "txtNombreItem";
            this.txtNombreItem.Size = new System.Drawing.Size(100, 22);
            this.txtNombreItem.TabIndex = 9;
            // 
            // btnCalcularTotal
            // 
            this.btnCalcularTotal.Location = new System.Drawing.Point(287, 278);
            this.btnCalcularTotal.Name = "btnCalcularTotal";
            this.btnCalcularTotal.Size = new System.Drawing.Size(75, 23);
            this.btnCalcularTotal.TabIndex = 10;
            this.btnCalcularTotal.Text = "Calcular";
            this.btnCalcularTotal.UseVisualStyleBackColor = true;
            this.btnCalcularTotal.Click += new System.EventHandler(this.btnCalcularTotal_Click);
            // 
            // btnAgregarItem
            // 
            this.btnAgregarItem.Location = new System.Drawing.Point(419, 278);
            this.btnAgregarItem.Name = "btnAgregarItem";
            this.btnAgregarItem.Size = new System.Drawing.Size(75, 23);
            this.btnAgregarItem.TabIndex = 11;
            this.btnAgregarItem.Text = "Agregar";
            this.btnAgregarItem.UseVisualStyleBackColor = true;
            this.btnAgregarItem.Click += new System.EventHandler(this.btnAgregarItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1351, 492);
            this.Controls.Add(this.btnAgregarItem);
            this.Controls.Add(this.btnCalcularTotal);
            this.Controls.Add(this.txtNombreItem);
            this.Controls.Add(this.txtPrecioItem);
            this.Controls.Add(this.txtCantidadItem);
            this.Controls.Add(this.txtNombreCliente);
            this.Controls.Add(this.lblNombreItem);
            this.Controls.Add(this.lblPrecioItem);
            this.Controls.Add(this.lblCantidadItem);
            this.Controls.Add(this.lblNombreCliente);
            this.Name = "Form1";
            this.Text = "factura";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNombreCliente;
        private System.Windows.Forms.Label lblCantidadItem;
        private System.Windows.Forms.Label lblPrecioItem;
        private System.Windows.Forms.Label lblNombreItem;
        private System.Windows.Forms.TextBox txtNombreCliente;
        private System.Windows.Forms.TextBox txtCantidadItem;
        private System.Windows.Forms.TextBox txtPrecioItem;
        private System.Windows.Forms.TextBox txtNombreItem;
        private System.Windows.Forms.Button btnCalcularTotal;
        private System.Windows.Forms.Button btnAgregarItem;
    }
}

