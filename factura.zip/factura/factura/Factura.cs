﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factura
{
  
    public class Factura
    {
        public string NombreCliente { get; set; }
        public DateTime Fecha { get; set; }
        public List<ItemFactura> Items { get; set; }

        public Factura(string nombreCliente, DateTime fecha)
        {
            NombreCliente = nombreCliente;
            Fecha = fecha;
            Items = new List<ItemFactura>();
        }

        public void AgregarItem(ItemFactura item)
        {
            Items.Add(item);
        }

        public double CalcularTotal()
        {
            double total = 0;
            foreach (var item in Items)
            {
                total += item.CalcularSubtotal();
            }
            return total;
        }
    }

    public class ItemFactura
    {
        public string Nombre { get; set; }
        public double PrecioUnitario { get; set; }
        public int Cantidad { get; set; }

        public ItemFactura(string nombre, double precioUnitario, int cantidad)
        {
            Nombre = nombre;
            PrecioUnitario = precioUnitario;
            Cantidad = cantidad;
        }

        public double CalcularSubtotal()
        {
            return PrecioUnitario * Cantidad;
        }
    }
}