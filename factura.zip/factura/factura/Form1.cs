﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace factura
{
    public partial class Form1 : Form
    {
        private Factura factura;
        public Form1()
        {

            InitializeComponent();
            factura = new Factura("", DateTime.Now);
        }

        private void btnAgregarItem_Click(object sender, EventArgs e)
        {
            string nombre = txtNombreItem.Text;
            double precio = double.Parse(txtPrecioItem.Text);
            int cantidad = int.Parse(txtCantidadItem.Text);

            ItemFactura item = new ItemFactura(nombre, precio, cantidad);
            factura.AgregarItem(item);

            // Limpiar los campos después de agregar un ítem
            txtNombreItem.Text = "";
            txtPrecioItem.Text = "";
            txtCantidadItem.Text = "";
        }

      
       
        private void btnCalcularTotal_Click(object sender, EventArgs e)
        {
            double total = factura.CalcularTotal();
            MessageBox.Show($"Total de la factura: {total.ToString("C")}");
        }


    }
}


